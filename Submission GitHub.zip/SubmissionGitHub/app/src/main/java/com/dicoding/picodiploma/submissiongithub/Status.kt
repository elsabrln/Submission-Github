package com.dicoding.picodiploma.submissiongithub

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
